Appendices
==========

.. toctree::
  :maxdepth: 2

  image-file-formats
  writing-your-own-file-decoder
