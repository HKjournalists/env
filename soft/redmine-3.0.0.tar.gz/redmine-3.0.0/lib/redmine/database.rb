# Redmine - project management software
# Copyright (C) 2006-2015  Jean-Philippe Lang
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

module Redmine
  # Helper module to get information about the Redmine database
  module Database
    class << self
      # Returns true if the database is PostgreSQL
      def postgresql?
        (ActiveRecord::Base.connection.adapter_name =~ /postgresql/i).present?
      end

      # Returns the PostgreSQL version or nil if another DBMS is used
      def postgresql_version
        postgresql? ? ActiveRecord::Base.connection.send(:postgresql_version) : nil
      end

      # Returns true if the database is a PostgreSQL >=9.0 database with the unaccent extension installed
      def postgresql_unaccent?
        if postgresql?
          return @postgresql_unaccent unless @postgresql_unaccent.nil?
          begin
            sql = "SELECT name FROM pg_available_extensions WHERE installed_version IS NOT NULL and name = 'unaccent'"
            @postgresql_unaccent = postgresql_version >= 90000 && ActiveRecord::Base.connection.select_value(sql).present?
          rescue
            false
          end
        else
          false
        end
      end

      # Resets database information
      def reset
        @postgresql_unaccent = nil
      end
    end
  end
end
